package com.example.arduinolock;

import static org.junit.Assert.*;

public class MainActivityTest {

}